#!/bin/sh
cd ../..
tar cvf tintin++v1.5.tar ./tintin++
compress tintin++v1.5.tar
echo Distribution packaged.

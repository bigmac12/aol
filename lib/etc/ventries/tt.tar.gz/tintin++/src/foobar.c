/* Autoconf patching by David Hedbor, neotron@lysator.liu.se */
#include < sys/termio.h >

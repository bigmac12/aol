#include "conf.h"
#include "sysdep.h"
 
 
#include "structs.h"
#include "utils.h"
#include "comm.h"
#include "interpreter.h"
#include "handler.h"
#include "db.h"
#include "screen.h"
 
#include "dg_scripts.h"
#include "spells.h"

/* The core CLI for the clans */

ACMD(do_clan)
{
	send_to_char("Narf!\r\n", ch);
}
